const express = require("express");
const path = require("path");
const puppeteer = require("puppeteer-core");
const { getVerifiedLatestResult } = require("./lottery-results");

const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.json({ limit: "10mb" }));
app.use(express.static(path.join(__dirname, "public")));

// Cache a successful verification briefly to avoid repeatedly requesting
// the external sources when multiple visitors open the website.
let latestVerifiedResult = null;
let latestVerifiedAt = 0;
let latestVerificationInFlight = null;
const RESULT_CACHE_MS = 2 * 60 * 1000;

// Fetch the latest result from the third-party API and verify every prize
// number against the official Kerala State Lotteries result publication.
app.get("/api/results/latest", async (req, res) => {
  try {
    if (latestVerifiedResult && Date.now() - latestVerifiedAt < RESULT_CACHE_MS) {
      return res.json(latestVerifiedResult);
    }
    if (!latestVerificationInFlight) {
      latestVerificationInFlight = getVerifiedLatestResult()
        .then(result => {
          latestVerifiedResult = result;
          latestVerifiedAt = Date.now();
          return result;
        })
        .finally(() => { latestVerificationInFlight = null; });
    }
    const result = await latestVerificationInFlight;
    res.set("Cache-Control", "no-store");
    res.json(result);
  } catch (error) {
    console.error("Lottery result verification failed:", error.message);
    res.status(502).json({
      verified: false,
      verificationStatus: "NOT_VERIFIED",
      message: error.message,
      details: error.details || [],
      draw: error.draw || null
    });
  }
});
app.post("/generate-pdf", async (req, res) => {
  try {
    const { htmlContent } = req.body;

    const browser = await puppeteer.connect({
      browserWSEndpoint: `wss://chrome.browserless.io?token=${process.env.BROWSERLESS_TOKEN}`
    });

    const page = await browser.newPage();

    await page.setContent(htmlContent, {
      waitUntil: "networkidle0"
    });

    const pdfBuffer = await page.pdf({
      format: "A4",
      printBackground: true
    });

    await browser.close();

    res.set({
      "Content-Type": "application/pdf",
      "Content-Disposition": "attachment; filename=full-result.pdf"
    });

    res.send(pdfBuffer);

  } catch (error) {
    console.error("PDF Error:", error);
    res.status(500).send("PDF generation failed");
  }
});

app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
});